package ar.edu.uba.fi;

public class ClienteNoRegistradoException extends RuntimeException {
}
