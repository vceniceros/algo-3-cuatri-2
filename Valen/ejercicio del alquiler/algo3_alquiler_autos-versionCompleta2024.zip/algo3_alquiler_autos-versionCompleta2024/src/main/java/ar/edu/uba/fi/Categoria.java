package ar.edu.uba.fi;

public interface Categoria {
    int precioPlazas(int plazas);
}
