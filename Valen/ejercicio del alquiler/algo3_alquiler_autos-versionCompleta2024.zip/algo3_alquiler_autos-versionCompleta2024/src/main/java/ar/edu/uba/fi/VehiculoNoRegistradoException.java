package ar.edu.uba.fi;

public class VehiculoNoRegistradoException extends RuntimeException {
}
