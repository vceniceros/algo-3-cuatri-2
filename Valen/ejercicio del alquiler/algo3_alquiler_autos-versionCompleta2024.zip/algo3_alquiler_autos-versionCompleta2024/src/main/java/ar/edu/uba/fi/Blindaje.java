package ar.edu.uba.fi;

public interface Blindaje {
    Double modificarPrecio(int precio);
}
