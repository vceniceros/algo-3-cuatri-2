package ar.edu.uba.fi;

public class VehiculoYaRegistradoException extends RuntimeException {
}
